# CuyoTech SSIS (fixed version)

## Setup (XAMPP)
1. Start **Apache** and **MySQL** in the XAMPP Control Panel.
2. Copy the folder `cuyotech-api` into `C:\xampp\htdocs\` (so it becomes `C:\xampp\htdocs\cuyotech-api`).
3. Open http://localhost/phpmyadmin → **Import** → choose `db/cuyotech_ssis.sql` → Go.
   (This DROPS and recreates the `cuyotech_ssis` database.)
4. In `my-react-app`, run:
   ```
   npm install
   npm run dev
   ```
5. Open the URL shown by Vite (usually http://localhost:5173).

If your MySQL root has a password, edit it in `cuyotech-api/db.php`.

## Demo accounts
| Role | Email | Password |
|---|---|---|
| Student | student@university.edu.ph | student123 |
| Registrar | registrar@university.edu.ph | registrar123 |
| Cashier | cashier@university.edu.ph | cashier123 |
| Department | department@university.edu.ph | department123 |
| System Admin | admin@university.edu.ph | admin123 |

## What each role can do
- **Student:** dashboard, grades, curriculum checklist, SOA, requirements and clearance, document requests, profile (read-only).
- **Registrar:** enroll a student in a course (blocked if the prerequisite is not yet passed), encode grades (1.00 to 3.00 passed, 5.00 failed), process document requests.
- **Cashier:** record payments (duplicate OR numbers are rejected) and print official receipts.
- **Department:** clear or hold clearances for the office assigned to the account.
- **System Admin:** everything above, plus create accounts, disable/enable accounts, reset passwords, and view the audit trail.

Registrar-to-Student integration: encode a grade as Registrar, then log in as that student and open Academic Grades.

## Troubleshooting
- "Cannot reach the server": Apache is not running, or the folder in htdocs is not named exactly `cuyotech-api`.
- "Cannot connect to the database": MySQL is not running or the SQL file was not imported.
- Test the API directly: http://localhost/cuyotech-api/api.php?action=me should answer `{"error":"Not signed in."}`.
