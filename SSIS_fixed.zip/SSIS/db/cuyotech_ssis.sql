-- CuyoTech SSIS database (3NF). Import in phpMyAdmin or: mysql -u root < cuyotech_ssis.sql
-- Demo passwords are stored as bcrypt hashes (password_hash). Demo logins:
--   admin@university.edu.ph / admin123      registrar@university.edu.ph / registrar123
--   cashier@university.edu.ph / cashier123  student@university.edu.ph / student123
--   department@university.edu.ph / department123
DROP DATABASE IF EXISTS cuyotech_ssis;
CREATE DATABASE cuyotech_ssis CHARACTER SET utf8mb4;
USE cuyotech_ssis;

CREATE TABLE Role (
  role_id INT AUTO_INCREMENT PRIMARY KEY,
  role_name VARCHAR(50) NOT NULL UNIQUE,
  description VARCHAR(255)
);
CREATE TABLE Department (
  department_id INT AUTO_INCREMENT PRIMARY KEY,
  department_name VARCHAR(100) NOT NULL UNIQUE
);
CREATE TABLE AdminUser (
  admin_id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(100) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  first_name VARCHAR(50) NOT NULL,
  last_name VARCHAR(50) NOT NULL,
  role_id INT NOT NULL,
  department_id INT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  FOREIGN KEY (role_id) REFERENCES Role(role_id),
  FOREIGN KEY (department_id) REFERENCES Department(department_id)
);
CREATE TABLE Student (
  student_id INT AUTO_INCREMENT PRIMARY KEY,
  student_no VARCHAR(20) NOT NULL UNIQUE,
  email VARCHAR(100) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  first_name VARCHAR(50) NOT NULL,
  last_name VARCHAR(50) NOT NULL,
  department_id INT NOT NULL,
  section VARCHAR(10),
  year_level TINYINT NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  FOREIGN KEY (department_id) REFERENCES Department(department_id)
);
-- Course replaces Subject; term is derived from year_level + semester (no redundant 'term' column)
CREATE TABLE Course (
  course_id INT AUTO_INCREMENT PRIMARY KEY,
  course_code VARCHAR(20) NOT NULL UNIQUE,
  course_title VARCHAR(100) NOT NULL,
  units TINYINT NOT NULL,
  year_level TINYINT NOT NULL,
  semester TINYINT NOT NULL,
  department_id INT NOT NULL,
  prerequisite_id INT NULL,
  FOREIGN KEY (department_id) REFERENCES Department(department_id),
  FOREIGN KEY (prerequisite_id) REFERENCES Course(course_id)
);
CREATE TABLE Enrollment (
  enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  course_id INT NOT NULL,
  school_year VARCHAR(9) NOT NULL,
  grade DECIMAL(3,2) NULL,
  status ENUM('Enrolled','Completed','Failed') NOT NULL DEFAULT 'Enrolled',
  UNIQUE (student_id, course_id),
  FOREIGN KEY (student_id) REFERENCES Student(student_id) ON DELETE CASCADE,
  FOREIGN KEY (course_id) REFERENCES Course(course_id)
);
CREATE TABLE EnrollmentCredential (
  credential_id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  document_name VARCHAR(100) NOT NULL,
  status ENUM('Verified','Incomplete','Pending') NOT NULL DEFAULT 'Pending',
  remarks VARCHAR(255),
  FOREIGN KEY (student_id) REFERENCES Student(student_id) ON DELETE CASCADE
);
CREATE TABLE Assessment (
  assessment_id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  school_year VARCHAR(9) NOT NULL,
  semester TINYINT NOT NULL,
  description VARCHAR(100) NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (student_id) REFERENCES Student(student_id) ON DELETE CASCADE
);
CREATE TABLE Payment (
  payment_id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  received_by INT NULL,
  or_number VARCHAR(30) NOT NULL UNIQUE,
  amount DECIMAL(10,2) NOT NULL,
  payment_date DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES Student(student_id) ON DELETE CASCADE,
  FOREIGN KEY (received_by) REFERENCES AdminUser(admin_id) ON DELETE SET NULL
);
CREATE TABLE Clearance (
  clearance_id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  department_id INT NOT NULL,
  status ENUM('Cleared','Pending') NOT NULL DEFAULT 'Pending',
  remarks VARCHAR(255),
  UNIQUE (student_id, department_id),
  FOREIGN KEY (student_id) REFERENCES Student(student_id) ON DELETE CASCADE,
  FOREIGN KEY (department_id) REFERENCES Department(department_id)
);
CREATE TABLE DocumentRequest (
  request_id INT AUTO_INCREMENT PRIMARY KEY,
  ref_no VARCHAR(20) UNIQUE NULL,
  student_id INT NOT NULL,
  processed_by INT NULL,
  document_type VARCHAR(60) NOT NULL,
  copies TINYINT NOT NULL DEFAULT 1,
  purpose VARCHAR(200) NOT NULL,
  status ENUM('Pending','Processing','Ready for release','Released','Rejected') NOT NULL DEFAULT 'Pending',
  request_date DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES Student(student_id) ON DELETE CASCADE,
  FOREIGN KEY (processed_by) REFERENCES AdminUser(admin_id) ON DELETE SET NULL
);
CREATE TABLE AuditTrail (
  log_id INT AUTO_INCREMENT PRIMARY KEY,
  admin_id INT NULL,
  action_description VARCHAR(255) NOT NULL,
  log_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (admin_id) REFERENCES AdminUser(admin_id) ON DELETE SET NULL
);

INSERT INTO Role (role_name, description) VALUES
('System Admin','Full access, user account management'),
('Registrar','Enrollment, grades, document requests'),
('Cashier','Payments and receipts'),
('Department','Clearance processing for the office/department');
INSERT INTO Department (department_name) VALUES
('College of Computing Studies'),('Library'),('Cashier''s Office'),('Guidance Office');
INSERT INTO AdminUser (email, password_hash, first_name, last_name, role_id, department_id) VALUES
('admin@university.edu.ph','$2y$10$TvlPA4.RCaXU0EgdcLrkZ.cK5RlNJhFGYE.8Lssdfy5h0uUJXR1Zm','System','Admin',1,NULL),
('registrar@university.edu.ph','$2y$10$CZWBToznhy.BZSeokUJBOeLJBW4OmxnADlmI3xg6u.qM69afzITWm','Maria','Santos',2,NULL),
('cashier@university.edu.ph','$2y$10$Hx71m42NWqYAfcDIJy29s.cBSsGhGUC9C/nKDN1MP940JvvK9Xn0m','Juan','Dela Cruz',3,NULL),
('department@university.edu.ph','$2y$10$od0FbO..jMC9Qgck8WaqIeamfnThcZ5d8pbGx.618w834sdYMh88i','Rico','Mendoza',4,1);
INSERT INTO Student (student_no, email, password_hash, first_name, last_name, department_id, section, year_level) VALUES
('CT-2024-08912','student@university.edu.ph','$2y$10$Z6FrNvfyl8wRcnON8o8/X.Btch8nVQqJ66icEamcPakhPjBiCADUW','John Aleks','Lumpay',1,'3IT-B',2),
('CT-2024-08913','vincent.mandap@university.edu.ph','$2y$10$Z6FrNvfyl8wRcnON8o8/X.Btch8nVQqJ66icEamcPakhPjBiCADUW','Vincent','Mandap',1,'3IT-B',2);

INSERT INTO Course (course_code, course_title, units, year_level, semester, department_id) VALUES
('CC 101','Introduction to Computing',3,1,1,1),
('CC 102','Computer Programming 1 (Fundamentals)',3,1,1,1),
('GE 1','Understanding the Self',3,1,1,1),
('GE 2','Readings in Philippine History',3,1,1,1),
('MATH 1','Mathematics in the Modern World',3,1,1,1),
('PE 1','Physical Fitness and Gymnastics',2,1,1,1),
('NSTP 1','National Service Training Program 1',3,1,1,1),
('CC 103','Computer Programming 2 (Object-Oriented)',3,1,2,1),
('IT 101','Platform Technologies',3,1,2,1),
('GE 3','The Contemporary World',3,1,2,1),
('GE 4','Purposive Communication',3,1,2,1),
('DI 101','Discrete Structures 1',3,1,2,1),
('PE 2','Rhythmic Activities',2,1,2,1),
('NSTP 2','National Service Training Program 2',3,1,2,1),
('CC 104','Data Structures and Algorithms',3,2,1,1),
('IT 102','Information Management (Database Systems)',3,2,1,1),
('IT 103','Networking 1 (Cisco Packet Tracer Basics)',3,2,1,1),
('GE 5','Art Appreciation',3,2,1,1),
('GE 6','Ethics',3,2,1,1),
('PE 3','Individual/Dual Sports',2,2,1,1);
-- prerequisites
UPDATE Course SET prerequisite_id=(SELECT course_id FROM (SELECT course_id FROM Course WHERE course_code='CC 103') x) WHERE course_code='CC 104';
UPDATE Course SET prerequisite_id=(SELECT course_id FROM (SELECT course_id FROM Course WHERE course_code='CC 102') x) WHERE course_code='IT 102';
UPDATE Course SET prerequisite_id=(SELECT course_id FROM (SELECT course_id FROM Course WHERE course_code='IT 101') x) WHERE course_code='IT 103';
UPDATE Course SET prerequisite_id=(SELECT course_id FROM (SELECT course_id FROM Course WHERE course_code='CC 102') x) WHERE course_code='CC 103';

INSERT INTO Enrollment (student_id, course_id, school_year, grade, status) VALUES
(1,1,'2025-2026',1.25,'Completed'),(1,2,'2025-2026',1.50,'Completed'),(1,3,'2025-2026',1.75,'Completed'),
(1,4,'2025-2026',1.25,'Completed'),(1,5,'2025-2026',2.00,'Completed'),(1,6,'2025-2026',1.50,'Completed'),
(1,7,'2025-2026',1.00,'Completed'),
(1,8,'2025-2026',1.50,'Completed'),(1,9,'2025-2026',1.75,'Completed'),(1,10,'2025-2026',1.25,'Completed'),
(1,11,'2025-2026',1.75,'Completed'),(1,12,'2025-2026',2.00,'Completed'),(1,13,'2025-2026',1.25,'Completed'),
(1,14,'2025-2026',1.00,'Completed'),
(1,15,'2026-2027',NULL,'Enrolled'),(1,16,'2026-2027',NULL,'Enrolled'),(1,17,'2026-2027',NULL,'Enrolled'),
(1,18,'2026-2027',NULL,'Enrolled'),(1,19,'2026-2027',NULL,'Enrolled'),(1,20,'2026-2027',NULL,'Enrolled');

INSERT INTO EnrollmentCredential (student_id, document_name, status, remarks) VALUES
(1,'Form 138 (High School Report Card)','Verified','Checked and approved by Admissions Office'),
(1,'Certificate of Good Moral Character','Verified','Original copy submitted'),
(1,'PSA Birth Certificate','Incomplete','Photocopy is blurred, need clear re-submission'),
(1,'Medical Clearance Form','Pending','Awaiting laboratory result validation'),
(2,'Form 138 (High School Report Card)','Verified','Complete');

-- 17 enrolled units x P550 = 9,350 tuition; P10,000 paid so far -> balance P4,650
INSERT INTO Assessment (student_id, school_year, semester, description, amount) VALUES
(1,'2026-2027',1,'Tuition Fee (17 Units x P550)',9350.00),
(1,'2026-2027',1,'Laboratory Fees',1800.00),
(1,'2026-2027',1,'Miscellaneous Fees',3500.00);
INSERT INTO Payment (student_id, received_by, or_number, amount, payment_date) VALUES
(1,3,'OR-2026-000145',10000.00,'2026-08-10 10:15:00');

INSERT INTO Clearance (student_id, department_id, status, remarks) VALUES
(1,1,'Cleared','No pending accountabilities'),
(1,2,'Cleared','No unreturned books'),
(1,3,'Pending','Outstanding balance on Statement of Account'),
(1,4,'Cleared','Completed'),
(2,1,'Pending','Awaiting department review'),
(2,2,'Pending','Awaiting library check'),
(2,3,'Pending','Awaiting cashier check'),
(2,4,'Pending','Awaiting guidance check');

INSERT INTO DocumentRequest (ref_no, student_id, document_type, copies, purpose, status) VALUES
('DR-2026-0001',1,'Certificate of Registration (COR)',1,'Scholarship application','Ready for release');
