// Thin wrapper around the PHP API. Session cookie is sent automatically (same-origin via Vite proxy).
export async function api(action, body) {
  const res = await fetch(`/api/api.php?action=${action}`, {
    method: body ? 'POST' : 'GET',
    credentials: 'same-origin',
    headers: body ? { 'Content-Type': 'application/json', 'X-Requested-With': 'ssis' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  })
  let data = null
  try { data = await res.json() } catch { /* non-JSON response (e.g. Apache not running) */ }
  if (!res.ok) {
    const err = new Error(data?.error || 'Cannot reach the server. Is XAMPP (Apache + MySQL) running?')
    err.status = res.status
    throw err
  }
  return data
}

export const peso = (n) => '₱' + Number(n).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
