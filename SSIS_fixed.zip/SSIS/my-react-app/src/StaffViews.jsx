import { useEffect, useState } from 'react'
import { api, peso } from './api'
import { Badge, statusTone, PageTitle, Table, card, input, btn, dateFmt } from './ui'

const STATUSES = ['Pending', 'Processing', 'Ready for release', 'Released', 'Rejected']
const GRADES = ['1.00', '1.25', '1.50', '1.75', '2.00', '2.25', '2.50', '2.75', '3.00', '5.00']

function useLoad(action) {
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)
  const load = () => api(action).then(setData).catch((e) => setError(e.message))
  useEffect(() => { load() }, [action]) // eslint-disable-line
  return [data, error, load]
}
const Msg = ({ m }) => m && <p role="status" className={`text-xs font-medium ${m.ok ? 'text-emerald-600' : 'text-red-600'}`}>{m.text}</p>
const Loading = ({ error }) => error ? <p role="alert" className="text-sm text-red-600">{error}</p> : <p className="text-sm opacity-60">Loading…</p>
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]))

/* ---------------- Registrar: document requests ---------------- */
export function RegistrarRequests() {
  const [data, error, load] = useLoad('staff_requests')
  if (!data) return <Loading error={error} />
  async function setStatus(id, status) { await api('update_request', { request_id: id, status }); load() }
  return (
    <div className="space-y-6">
      <PageTitle title="Document Requests" sub="Process student requests for TOR, COR, and certifications." />
      <div className={`${card} p-6`}>
        <Table head={['Reference', 'Student', 'Document', 'Copies', 'Purpose', 'Date', 'Status']} empty={data.requests.length ? null : 'No requests.'}>
          {data.requests.map((r) => (
            <tr key={r.request_id}>
              <td className="py-3 font-semibold">{r.ref_no}</td><td>{r.student}<br /><span className="opacity-50">{r.student_no}</span></td>
              <td>{r.document_type}</td><td>{r.copies}</td><td>{r.purpose}</td><td>{dateFmt(r.request_date)}</td>
              <td>
                <select value={r.status} onChange={(e) => setStatus(r.request_id, e.target.value)} aria-label={`Status for ${r.ref_no}`} className={`${input} py-1.5 text-xs w-auto`}>
                  {STATUSES.map((s) => <option key={s}>{s}</option>)}
                </select>
              </td>
            </tr>
          ))}
        </Table>
      </div>
    </div>
  )
}

/* ---------------- Registrar: enrollment & grades ---------------- */
function GradeCell({ row, onSaved, setMsg }) {
  const [g, setG] = useState(row.grade ? Number(row.grade).toFixed(2) : '')
  async function save() {
    try { await api('encode_grade', { enrollment_id: row.enrollment_id, grade: g }); setMsg({ ok: true, text: `Grade saved for ${row.course_code}.` }); onSaved() }
    catch (e) { setMsg({ ok: false, text: e.message }) }
  }
  return (
    <div className="flex gap-2">
      <select value={g} onChange={(e) => setG(e.target.value)} aria-label={`Grade for ${row.course_code}`} className={`${input} py-1.5 text-xs w-24`}>
        <option value="">Grade…</option>{GRADES.map((x) => <option key={x}>{x}</option>)}
      </select>
      <button onClick={save} disabled={!g} className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-blue-600 text-white disabled:opacity-40">Save</button>
    </div>
  )
}

export function RegistrarGrades() {
  const [students, error] = useLoad('registrar_students')
  const [no, setNo] = useState('')
  const [courses, setCourses] = useState(null)
  const [msg, setMsg] = useState(null)

  const loadCourses = (n = no) => n && api(`registrar_courses&student_no=${encodeURIComponent(n)}`).then((d) => setCourses(d.courses)).catch((e) => setMsg({ ok: false, text: e.message }))
  async function pick(n) { setNo(n); setMsg(null); setCourses(null); loadCourses(n) }
  async function enroll(c) {
    try { await api('enroll_student', { student_no: no, course_id: c.course_id }); setMsg({ ok: true, text: `Enrolled in ${c.course_code}.` }); loadCourses() }
    catch (e) { setMsg({ ok: false, text: e.message }) }
  }
  if (!students) return <Loading error={error} />

  return (
    <div className="space-y-6">
      <PageTitle title="Enrollment & Grades Encoding" sub="Enroll a student in a course and encode final grades. Changes appear in the Student Portal right away." />
      <div className={`${card} p-6 flex flex-wrap items-end gap-4`}>
        <div className="min-w-64">
          <label htmlFor="stu-pick" className="block text-xs font-semibold mb-1.5">Student</label>
          <select id="stu-pick" value={no} onChange={(e) => pick(e.target.value)} className={input}>
            <option value="">Select a student…</option>
            {students.students.map((s) => <option key={s.student_no} value={s.student_no}>{s.name} ({s.student_no})</option>)}
          </select>
        </div>
        <Msg m={msg} />
      </div>
      {courses && (
        <div className={`${card} p-6`}>
          <Table head={['Year / Sem', 'Code', 'Description', 'Units', 'Prerequisite', 'Status', 'Action / Grade']}>
            {courses.map((c) => (
              <tr key={c.course_id}>
                <td className="py-3">{c.year_level}-{c.semester}</td><td className="font-semibold">{c.course_code}</td><td>{c.course_title}</td><td>{c.units}</td>
                <td>{c.prereq_code ? <span className={c.prereq_met ? '' : 'text-red-600'}>{c.prereq_code}{c.prereq_met ? '' : ' (not passed)'}</span> : '—'}</td>
                <td><Badge tone={statusTone(c.status)}>{c.status || 'Not enrolled'}</Badge></td>
                <td>
                  {c.enrollment_id
                    ? <GradeCell key={`${c.enrollment_id}-${c.grade}`} row={c} onSaved={loadCourses} setMsg={setMsg} />
                    : <button onClick={() => enroll(c)} disabled={!c.prereq_met} title={c.prereq_met ? '' : 'Prerequisite not yet passed'}
                        className="px-3 py-1.5 text-xs font-semibold rounded-lg border border-blue-600 text-blue-600 disabled:opacity-40 disabled:cursor-not-allowed">Enroll</button>}
                </td>
              </tr>
            ))}
          </Table>
        </div>
      )}
    </div>
  )
}

/* ---------------- Department: clearance ---------------- */
export function DepartmentClearance() {
  const [data, error, load] = useLoad('staff_clearance')
  const [msg, setMsg] = useState(null)
  const [notes, setNotes] = useState({})
  if (!data) return <Loading error={error} />
  async function set(c, status) {
    try { await api('update_clearance', { clearance_id: c.clearance_id, status, remarks: notes[c.clearance_id] ?? c.remarks ?? '' }); setMsg({ ok: true, text: `${c.student}: ${status}.` }); load() }
    catch (e) { setMsg({ ok: false, text: e.message }) }
  }
  return (
    <div className="space-y-6">
      <PageTitle title="Clearance Processing" sub="Clear or hold a student's clearance for your office." />
      <Msg m={msg} />
      <div className={`${card} p-6`}>
        <Table head={['Student', 'Office', 'Status', 'Remarks', 'Action']} empty={data.clearances.length ? null : 'No clearance records.'}>
          {data.clearances.map((c) => (
            <tr key={c.clearance_id}>
              <td className="py-3 font-semibold">{c.student}<br /><span className="font-normal opacity-50">{c.student_no}</span></td>
              <td>{c.department_name}</td>
              <td><Badge tone={statusTone(c.status)}>{c.status}</Badge></td>
              <td><input aria-label={`Remarks for ${c.student}`} defaultValue={c.remarks} maxLength={255} onChange={(e) => setNotes({ ...notes, [c.clearance_id]: e.target.value })} className={`${input} py-1.5 text-xs`} /></td>
              <td className="whitespace-nowrap">
                <button onClick={() => set(c, 'Cleared')} className="px-3 py-1.5 mr-2 text-xs font-semibold rounded-lg bg-emerald-600 text-white">Clear</button>
                <button onClick={() => set(c, 'Pending')} className="px-3 py-1.5 text-xs font-semibold rounded-lg border border-amber-500 text-amber-600">Hold</button>
              </td>
            </tr>
          ))}
        </Table>
      </div>
    </div>
  )
}

/* ---------------- Cashier: payments + printable receipt ---------------- */
function printReceipt(r) {
  const w = window.open('', '_blank', 'width=520,height=640')
  if (!w) return alert('Please allow pop-ups to print the receipt.')
  w.document.write(`<!doctype html><title>Receipt ${esc(r.or_number)}</title>
  <style>body{font-family:Arial,sans-serif;max-width:420px;margin:24px auto;color:#111}h1{font-size:16px;text-align:center;margin:0}
  p.s{text-align:center;font-size:12px;margin:2px 0 16px}table{width:100%;border-collapse:collapse;font-size:13px}td{padding:6px 0;border-bottom:1px solid #ddd}
  td:last-child{text-align:right;font-weight:600}.t td{font-size:15px;border-bottom:2px solid #111}.f{font-size:11px;text-align:center;margin-top:24px}</style>
  <h1>CuyoTech University</h1><p class="s">Official Receipt · Cashier's Office</p>
  <table>
  <tr><td>OR Number</td><td>${esc(r.or_number)}</td></tr>
  <tr><td>Date</td><td>${esc(dateFmt(r.payment_date))}</td></tr>
  <tr><td>Student</td><td>${esc(r.student)}</td></tr>
  <tr><td>Student No.</td><td>${esc(r.student_no)}</td></tr>
  <tr class="t"><td>Amount Paid</td><td>${esc(peso(r.amount))}</td></tr>
  <tr><td>Remaining Balance</td><td>${esc(peso(r.balance))}</td></tr>
  <tr><td>Received by</td><td>${esc(r.cashier)}</td></tr></table>
  <p class="f">This is a system-generated receipt.</p>
  <script>window.onload=()=>window.print()</script>`)
  w.document.close()
}

export function CashierPayments() {
  const [data, error, load] = useLoad('staff_payments')
  const [form, setForm] = useState({ student_no: '', amount: '', or_number: '' })
  const [msg, setMsg] = useState(null)
  if (!data) return <Loading error={error} />
  const receipt = async (or) => { try { printReceipt(await api(`receipt&or=${encodeURIComponent(or)}`)) } catch (e) { setMsg({ ok: false, text: e.message }) } }
  async function submit(e) {
    e.preventDefault(); setMsg(null)
    try {
      await api('record_payment', { ...form, amount: +form.amount })
      setMsg({ ok: true, text: 'Payment recorded. Printing receipt…' })
      const or = form.or_number
      setForm({ student_no: '', amount: '', or_number: '' }); load(); receipt(or)
    } catch (err) { setMsg({ ok: false, text: err.message }) }
  }
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value })
  return (
    <div className="space-y-6">
      <PageTitle title="Cashier · Payments" sub="Record payments and print official receipts." />
      <form onSubmit={submit} className={`${card} p-6 grid sm:grid-cols-4 gap-4 items-end`}>
        <div><label htmlFor="stu" className="block text-xs font-semibold mb-1.5">Student</label>
          <select id="stu" value={form.student_no} onChange={set('student_no')} className={input} required>
            <option value="">Select…</option>{data.students.map((s) => <option key={s.student_no} value={s.student_no}>{s.name} ({s.student_no})</option>)}
          </select></div>
        <div><label htmlFor="amt" className="block text-xs font-semibold mb-1.5">Amount (₱)</label>
          <input id="amt" type="number" min="1" step="0.01" value={form.amount} onChange={set('amount')} className={input} required /></div>
        <div><label htmlFor="or" className="block text-xs font-semibold mb-1.5">OR number</label>
          <input id="or" value={form.or_number} onChange={set('or_number')} placeholder="OR-2026-000201" className={input} required /></div>
        <button className={btn}>Record payment</button>
        <div className="sm:col-span-4"><Msg m={msg} /></div>
      </form>
      <div className={`${card} p-6`}>
        <Table head={['OR Number', 'Student', 'Date', 'Amount', '']} empty={data.payments.length ? null : 'No payments.'}>
          {data.payments.map((p) => (
            <tr key={p.or_number}>
              <td className="py-3 font-semibold">{p.or_number}</td><td>{p.student}</td><td>{dateFmt(p.payment_date)}</td><td className="font-semibold">{peso(p.amount)}</td>
              <td><button onClick={() => receipt(p.or_number)} className="text-blue-600 hover:underline font-semibold">Print receipt</button></td>
            </tr>
          ))}
        </Table>
      </div>
    </div>
  )
}

/* ---------------- Admin: users ---------------- */
function CreateUser({ onDone }) {
  const blank = { kind: 'student', email: '', first_name: '', last_name: '', password: '', role: 'Registrar', student_no: '', section: '', year_level: 1 }
  const [f, setF] = useState(blank)
  const [msg, setMsg] = useState(null)
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })
  async function submit(e) {
    e.preventDefault(); setMsg(null)
    try { await api('create_user', { ...f, year_level: +f.year_level }); setMsg({ ok: true, text: 'Account created.' }); setF(blank); onDone() }
    catch (err) { setMsg({ ok: false, text: err.message }) }
  }
  const field = (id, label, extra = {}) => (
    <div><label htmlFor={id} className="block text-xs font-semibold mb-1.5">{label}</label>
      <input id={id} value={f[extra.key || id]} onChange={set(extra.key || id)} className={input} required={extra.req !== false} {...extra.props} /></div>
  )
  return (
    <form onSubmit={submit} className={`${card} p-6 space-y-4`}>
      <h3 className="font-bold text-sm">Create account</h3>
      <div className="grid sm:grid-cols-4 gap-4">
        <div><label htmlFor="kind" className="block text-xs font-semibold mb-1.5">Account type</label>
          <select id="kind" value={f.kind} onChange={set('kind')} className={input}><option value="student">Student</option><option value="staff">Staff</option></select></div>
        {field('first_name', 'First name')}{field('last_name', 'Last name')}{field('email', 'University email', { props: { type: 'email' } })}
        {f.kind === 'staff'
          ? <div><label htmlFor="role" className="block text-xs font-semibold mb-1.5">Role</label>
              <select id="role" value={f.role} onChange={set('role')} className={input}>{['Registrar', 'Cashier', 'Department', 'System Admin'].map((r) => <option key={r}>{r}</option>)}</select></div>
          : <>{field('student_no', 'Student number')}{field('section', 'Section')}
              <div><label htmlFor="yl" className="block text-xs font-semibold mb-1.5">Year level</label>
                <select id="yl" value={f.year_level} onChange={set('year_level')} className={input}>{[1, 2, 3, 4].map((y) => <option key={y}>{y}</option>)}</select></div></>}
        {field('password', 'Initial password (min. 8)', { props: { type: 'password', minLength: 8, autoComplete: 'new-password' } })}
      </div>
      <div className="flex items-center gap-4"><button className={btn}>Create account</button><Msg m={msg} /></div>
    </form>
  )
}

function UserRow({ u, kind, onChange, setMsg }) {
  const [resetting, setResetting] = useState(false)
  const [pw, setPw] = useState('')
  const run = async (action, body, ok) => {
    try { await api(action, { kind, id: u.id, ...body }); setMsg({ ok: true, text: ok }); setResetting(false); setPw(''); onChange() }
    catch (e) { setMsg({ ok: false, text: e.message }) }
  }
  return (
    <tr>
      <td className="py-3 font-semibold">{u.name}</td>
      <td>{kind === 'staff' ? <Badge tone="blue">{u.role}</Badge> : u.student_no}</td>
      <td>{u.email}</td>
      <td><Badge tone={u.is_active ? 'green' : 'red'}>{u.is_active ? 'Active' : 'Disabled'}</Badge></td>
      <td className="whitespace-nowrap">
        {resetting ? (
          <span className="flex gap-2 items-center">
            <input type="password" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="New password" aria-label={`New password for ${u.name}`} className={`${input} py-1.5 text-xs w-36`} />
            <button disabled={pw.length < 8} onClick={() => run('reset_password', { password: pw }, `Password reset for ${u.name}.`)} className="text-blue-600 font-semibold disabled:opacity-40">Save</button>
            <button onClick={() => setResetting(false)} className="opacity-60">Cancel</button>
          </span>
        ) : (
          <span className="flex gap-4">
            <button onClick={() => setResetting(true)} className="text-blue-600 hover:underline font-semibold">Reset password</button>
            <button onClick={() => run('set_active', { active: !u.is_active }, `${u.name} ${u.is_active ? 'disabled' : 'enabled'}.`)} className={`${u.is_active ? 'text-red-600' : 'text-emerald-600'} hover:underline font-semibold`}>{u.is_active ? 'Disable' : 'Enable'}</button>
          </span>
        )}
      </td>
    </tr>
  )
}

export function AdminUsers() {
  const [data, error, load] = useLoad('admin_users')
  const [msg, setMsg] = useState(null)
  if (!data) return <Loading error={error} />
  return (
    <div className="space-y-6">
      <PageTitle title="User Accounts & Audit Trail" sub="Create accounts, disable access, and reset passwords. Every action is logged." />
      <Msg m={msg} />
      <CreateUser onDone={load} />
      <div className={`${card} p-6`}>
        <h3 className="font-bold text-sm mb-3">Staff accounts</h3>
        <Table head={['Name', 'Role', 'Email', 'Status', 'Actions']}>{data.staff.map((u) => <UserRow key={u.id} u={u} kind="staff" onChange={load} setMsg={setMsg} />)}</Table>
      </div>
      <div className={`${card} p-6`}>
        <h3 className="font-bold text-sm mb-3">Student accounts</h3>
        <Table head={['Name', 'Student No.', 'Email', 'Status', 'Actions']}>{data.students.map((u) => <UserRow key={u.id} u={u} kind="student" onChange={load} setMsg={setMsg} />)}</Table>
      </div>
      <div className={`${card} p-6`}>
        <h3 className="font-bold text-sm mb-3">Recent activity (audit trail)</h3>
        <Table head={['When', 'Who', 'Action']} empty={data.audit.length ? null : 'No activity.'}>
          {data.audit.map((a, i) => <tr key={i}><td className="py-3">{dateFmt(a.log_timestamp)}</td><td>{a.who}</td><td>{a.action_description}</td></tr>)}
        </Table>
      </div>
    </div>
  )
}
