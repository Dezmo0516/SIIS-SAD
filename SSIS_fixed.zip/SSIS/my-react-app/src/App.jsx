import { useEffect, useState } from 'react'
import { api } from './api'
import { input, btn } from './ui'
import { Dashboard, Profile, Grades, Curriculum, Soa, Requirements, Documents } from './StudentViews'
import { RegistrarRequests, RegistrarGrades, DepartmentClearance, CashierPayments, AdminUsers } from './StaffViews'

const STUDENT_TABS = [
  ['dashboard', 'Dashboard'], ['grades', 'Academic Grades'], ['curriculum', 'Curriculum Checklist'],
  ['soa', 'Statement of Account'], ['requirements', 'Requirements & Clearance'],
  ['documents', 'Document Requests'], ['profile', 'Student Profile'],
]
const STAFF_TABS = {
  Registrar: [['grades', 'Enrollment & Grades'], ['requests', 'Document Requests']],
  Cashier: [['payments', 'Payments']],
  Department: [['clearance', 'Clearance']],
  'System Admin': [['grades', 'Enrollment & Grades'], ['requests', 'Document Requests'], ['payments', 'Payments'], ['clearance', 'Clearance'], ['users', 'Users & Audit Trail']],
}

function Login({ onLogin, dark, toggleDark }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)
  const [busy, setBusy] = useState(false)

  async function submit(e) {
    e.preventDefault(); setBusy(true); setError(null)
    try { onLogin(await api('login', { email, password })) }
    catch (err) { setError(err.message) }
    setBusy(false)
  }
  return (
    <div className="min-h-screen grid grid-cols-1 lg:grid-cols-12 font-sans bg-[#f4f6f9] text-slate-800 dark:bg-[#0b131d] dark:text-slate-100">
      <div className="lg:col-span-7 p-12 lg:p-20 flex flex-col justify-between bg-[#1b2a4a] text-white dark:bg-[#0f172a]">
        <div>
          <div className="flex items-center justify-between mb-12">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center font-bold text-lg">U</div>
              <span className="font-bold tracking-wider text-sm">CuyoTech University</span>
            </div>
            <button onClick={toggleDark} className="px-3.5 py-1.5 rounded-lg text-xs font-medium bg-white/10 hover:bg-white/20 border border-white/10">{dark ? 'Light mode' : 'Dark mode'}</button>
          </div>
          <h1 className="text-4xl lg:text-5xl font-extrabold tracking-tight mb-4 leading-tight">Student Services Information System</h1>
          <p className="text-sm max-w-md leading-relaxed text-blue-100/80">Enrollment records, grades, clearance, payments, and document requests in one place, without the queue.</p>
        </div>
        <p className="text-xs text-blue-200/60 pt-10">Academic Year 2026–2027 · 1st Semester</p>
      </div>
      <div className="lg:col-span-5 p-8 lg:p-16 flex items-center justify-center">
        <div className="w-full max-w-md">
          <h2 className="text-2xl font-bold tracking-tight">Institutional Login</h2>
          <p className="text-sm mt-1 opacity-60 mb-6">Sign in with your university email.</p>
          <form onSubmit={submit} className="p-7 rounded-2xl border shadow-sm space-y-4 bg-white border-slate-200/80 dark:bg-[#0f172a] dark:border-slate-800">
            <div>
              <label htmlFor="email" className="block text-xs font-semibold mb-1.5">University email</label>
              <input id="email" type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} className={input} required />
            </div>
            <div>
              <label htmlFor="password" className="block text-xs font-semibold mb-1.5">Password</label>
              <input id="password" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} className={input} required />
            </div>
            {error && <p role="alert" className="text-xs font-medium text-red-600">{error}</p>}
            <button className={`${btn} w-full`} disabled={busy}>{busy ? 'Signing in…' : 'Sign in to portal'}</button>
          </form>
        </div>
      </div>
    </div>
  )
}

function Shell({ user, onLogout, dark, toggleDark }) {
  const isStudent = user.kind === 'student'
  const tabs = isStudent ? STUDENT_TABS : STAFF_TABS[user.role] || []
  const [tab, setTab] = useState(tabs[0][0])
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)

  const reload = () => api('portal').then(setData).catch((e) => setError(e.message))
  useEffect(() => { if (isStudent) reload() }, [isStudent])

  let body = null
  if (isStudent) {
    if (error) body = <p role="alert" className="text-sm text-red-600">{error}</p>
    else if (!data) body = <p className="text-sm opacity-60">Loading your records…</p>
    else body = {
      dashboard: <Dashboard d={data} />, grades: <Grades d={data} />, curriculum: <Curriculum d={data} />,
      soa: <Soa d={data} />, requirements: <Requirements d={data} />,
      documents: <Documents d={data} reload={reload} />, profile: <Profile d={data} />,
    }[tab]
  } else {
    body = { requests: <RegistrarRequests />, grades: <RegistrarGrades />, clearance: <DepartmentClearance />, payments: <CashierPayments />, users: <AdminUsers /> }[tab]
  }

  return (
    <div className="min-h-screen flex font-sans bg-[#f4f6f9] text-slate-800 dark:bg-[#0b131d] dark:text-slate-100">
      <aside className="w-64 hidden md:flex flex-col justify-between bg-[#1b2a4a] text-white dark:bg-[#0f172a] border-r border-transparent dark:border-slate-800/80">
        <div>
          <div className="p-6 border-b border-blue-900/40">
            <h2 className="font-bold text-sm tracking-wide">CUYOTECH SSIS</h2>
            <p className="text-[11px] font-medium text-blue-300">{isStudent ? 'Student Portal' : `${user.role} Module`}</p>
          </div>
          <nav className="p-4 space-y-1 text-sm font-medium">
            {tabs.map(([id, label]) => (
              <button key={id} onClick={() => setTab(id)} aria-current={tab === id ? 'page' : undefined}
                className={`w-full text-left px-3.5 py-2.5 rounded-lg transition ${tab === id ? 'bg-blue-600 font-semibold' : 'text-blue-100 hover:bg-white/10'}`}>{label}</button>
            ))}
          </nav>
        </div>
        <div className="p-4 border-t border-blue-900/40 flex items-center justify-between gap-2">
          <div className="overflow-hidden">
            <p className="text-xs font-bold truncate">{user.name}</p>
            <p className="text-[10px] text-blue-300">{user.role}</p>
          </div>
          <button onClick={toggleDark} className="px-2 py-1 rounded-lg text-[11px] border border-white/20 bg-white/10 hover:bg-white/20">{dark ? 'Light' : 'Dark'}</button>
        </div>
      </aside>
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="px-8 py-3.5 flex justify-between items-center border-b sticky top-0 z-10 bg-white border-slate-200/80 dark:bg-[#0f172a] dark:border-slate-800">
          <select value={tab} onChange={(e) => setTab(e.target.value)} aria-label="Navigate" className="md:hidden text-xs bg-transparent border rounded px-2 py-1">
            {tabs.map(([id, label]) => <option key={id} value={id}>{label}</option>)}
          </select>
          <span className="hidden md:block text-xs opacity-70">{user.name}</span>
          <button onClick={onLogout} className="text-xs font-medium text-red-500 hover:underline">Logout</button>
        </header>
        <main className="p-8 w-full max-w-6xl mx-auto">{body}</main>
      </div>
    </div>
  )
}

export default function App() {
  const [user, setUser] = useState(null)
  const [ready, setReady] = useState(false)
  const [dark, setDark] = useState(() => { try { return localStorage.getItem('ssis-dark') === '1' } catch { return false } })

  useEffect(() => { api('me').then(setUser).catch(() => {}).finally(() => setReady(true)) }, [])
  useEffect(() => { try { localStorage.setItem('ssis-dark', dark ? '1' : '0') } catch { /* ignore */ } }, [dark])

  const logout = async () => { await api('logout', {}).catch(() => {}); setUser(null) }
  if (!ready) return null
  const props = { dark, toggleDark: () => setDark(!dark) }
  return (
    <div className={dark ? 'dark' : ''}>
      {user ? <Shell key={user.name} user={user} onLogout={logout} {...props} /> : <Login onLogin={setUser} {...props} />}
    </div>
  )
}
