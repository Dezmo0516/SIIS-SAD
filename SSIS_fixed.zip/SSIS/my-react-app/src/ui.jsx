export const card = 'bg-white dark:bg-[#0f172a] border border-slate-200/80 dark:border-slate-800 rounded-xl shadow-sm'
export const input = 'w-full px-3.5 py-2.5 text-sm rounded-lg border bg-slate-50 border-slate-300 text-slate-900 dark:bg-slate-900 dark:border-slate-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-600'
export const btn = 'px-4 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white font-semibold text-sm rounded-lg transition'

const tones = {
  green: 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/20',
  amber: 'bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/20',
  red: 'bg-red-500/10 text-red-700 dark:text-red-400 border-red-500/20',
  blue: 'bg-blue-500/10 text-blue-700 dark:text-blue-400 border-blue-500/20',
  gray: 'bg-slate-500/10 text-slate-600 dark:text-slate-400 border-slate-500/20',
}
export function Badge({ tone = 'gray', children }) {
  return <span className={`inline-block px-2.5 py-1 text-xs font-semibold rounded-md border ${tones[tone]}`}>{children}</span>
}
export const statusTone = (s) =>
  ({ Verified: 'green', Cleared: 'green', Completed: 'green', Released: 'green', 'Ready for release': 'green',
     Incomplete: 'red', Failed: 'red', Rejected: 'red',
     Pending: 'amber', Enrolled: 'blue', Processing: 'blue' }[s] || 'gray')

export function PageTitle({ title, sub }) {
  return (
    <div>
      <h1 className="text-2xl font-bold">{title}</h1>
      {sub && <p className="text-xs opacity-60 mt-1">{sub}</p>}
    </div>
  )
}
export function Table({ head, children, empty }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left text-xs">
        <thead>
          <tr className="border-b border-slate-200 dark:border-slate-800 opacity-60">
            {head.map((h, i) => <th key={i} className="pb-2.5 pr-4 font-semibold">{h}</th>)}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
          {children}
          {empty && <tr><td colSpan={head.length} className="py-6 text-center opacity-50">{empty}</td></tr>}
        </tbody>
      </table>
    </div>
  )
}
export const dateFmt = (s) => new Date(s.replace(' ', 'T')).toLocaleDateString('en-PH', { year: 'numeric', month: 'short', day: 'numeric' })
