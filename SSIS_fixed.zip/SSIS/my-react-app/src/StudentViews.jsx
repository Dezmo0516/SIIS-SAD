import { useState } from 'react'
import { api, peso } from './api'
import { Badge, statusTone, PageTitle, Table, card, input, btn, dateFmt } from './ui'

export function Dashboard({ d }) {
  const cleared = d.clearance.filter((c) => c.status === 'Cleared').length
  const stats = [
    ['Enrolled Units', d.summary.enrolled_units],
    ['Cumulative GWA', d.summary.gwa ?? 'N/A'],
    ['Account Balance', peso(d.soa.balance)],
    ['Clearance', `${cleared} of ${d.clearance.length} cleared`],
  ]
  return (
    <div className="space-y-6">
      <div className={`${card} p-6 flex flex-col sm:flex-row justify-between gap-4 sm:items-center`}>
        <div>
          <h1 className="text-2xl font-bold">Welcome back, {d.profile.first_name}</h1>
          <p className="text-xs opacity-60 mt-1">{d.profile.department_name} · Bachelor of Science in Information Technology</p>
        </div>
        <Badge tone="green">Officially Enrolled</Badge>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map(([label, v]) => (
          <div key={label} className={`${card} p-5`}>
            <p className="text-2xl font-bold">{v}</p>
            <p className="text-xs opacity-60 mt-1">{label}</p>
          </div>
        ))}
      </div>
      <div className={`${card} p-6`}>
        <h3 className="font-bold text-sm mb-3">Recent document requests</h3>
        <Table head={['Reference', 'Document', 'Status']} empty={d.documents.length ? null : 'No requests yet.'}>
          {d.documents.slice(0, 3).map((r) => (
            <tr key={r.ref_no}><td className="py-3 font-semibold">{r.ref_no}</td><td>{r.document_type}</td><td><Badge tone={statusTone(r.status)}>{r.status}</Badge></td></tr>
          ))}
        </Table>
      </div>
    </div>
  )
}

export function Profile({ d }) {
  const p = d.profile
  const fields = [
    ['Full Name', `${p.first_name} ${p.last_name}`], ['Student ID Number', p.student_no],
    ['Institutional Email', p.email], ['Degree Program & Section', `BS Information Technology (${p.section})`],
    ['College Department', p.department_name], ['Year Level', `${p.year_level}`],
  ]
  return (
    <div className="space-y-6">
      <PageTitle title="Student Profile" sub="Records are managed by the Office of the Registrar." />
      <div className="p-4 rounded-xl border text-xs bg-amber-50 border-amber-200 text-amber-800 dark:bg-amber-950/20 dark:border-amber-900/40 dark:text-amber-300">
        <p className="font-bold">Restricted profile modification</p>
        <p className="mt-0.5">Students cannot edit these fields. Contact the Registrar for corrections.</p>
      </div>
      <div className={`${card} p-6 grid sm:grid-cols-2 gap-6 text-xs`}>
        {fields.map(([l, v]) => (
          <div key={l}>
            <label className="block font-semibold opacity-60 mb-1">{l}</label>
            <input value={v} disabled className={`${input} opacity-80 cursor-not-allowed`} />
          </div>
        ))}
      </div>
    </div>
  )
}

const semLabel = (y, s) => `${['', '1st', '2nd', '3rd', '4th'][y]} Year · ${s === 1 ? '1st' : '2nd'} Semester`

export function Grades({ d }) {
  const taken = d.courses.filter((c) => c.status)
  const groups = {}
  taken.forEach((c) => { (groups[`${c.school_year}|${c.year_level}|${c.semester}`] ||= []).push(c) })
  return (
    <div className="space-y-6">
      <PageTitle title="Academic Grades" sub="Official per-semester grades. Current-semester grades appear once the Registrar encodes them." />
      {Object.entries(groups).sort().reverse().map(([k, rows]) => {
        const [sy, y, s] = k.split('|')
        return (
          <div key={k} className={`${card} p-6`}>
            <h3 className="font-bold text-sm text-blue-600 dark:text-blue-400 mb-4">AY {sy} · {semLabel(+y, +s)}</h3>
            <Table head={['Course Code', 'Description', 'Units', 'Grade', 'Status']}>
              {rows.map((c) => (
                <tr key={c.course_code}>
                  <td className="py-3 font-semibold">{c.course_code}</td><td>{c.course_title}</td><td>{c.units}</td>
                  <td className="font-bold">{c.grade ?? <span className="opacity-40 font-normal">N/A</span>}</td>
                  <td><Badge tone={statusTone(c.status)}>{c.status}</Badge></td>
                </tr>
              ))}
            </Table>
          </div>
        )
      })}
    </div>
  )
}

export function Curriculum({ d }) {
  const [year, setYear] = useState(1)
  const rows = d.courses.filter((c) => c.year_level === year)
  const label = (c) => c.status || 'Not yet taken'
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <PageTitle title="BSIT Prospectus" sub="Curriculum checklist with prerequisite information." />
        <select value={year} onChange={(e) => setYear(+e.target.value)} className={`${input} w-auto`} aria-label="Year level">
          {[1, 2].map((y) => <option key={y} value={y}>{y === 1 ? '1st' : '2nd'} Year</option>)}
        </select>
      </div>
      {[1, 2].map((sem) => {
        const list = rows.filter((c) => c.semester === sem)
        return (
          <div key={sem} className={`${card} p-6`}>
            <h3 className="font-bold text-sm mb-4">{sem === 1 ? 'First' : 'Second'} Semester</h3>
            <Table head={['Code', 'Description', 'Units', 'Prerequisite', 'Grade', 'Status']} empty={list.length ? null : 'No courses listed for this semester yet.'}>
              {list.map((c) => (
                <tr key={c.course_code}>
                  <td className="py-3 font-semibold">{c.course_code}</td><td>{c.course_title}</td><td>{c.units}</td>
                  <td>{c.prereq_code || '—'}</td><td>{c.grade ?? '—'}</td>
                  <td><Badge tone={statusTone(c.status)}>{label(c)}</Badge></td>
                </tr>
              ))}
            </Table>
          </div>
        )
      })}
    </div>
  )
}

export function Soa({ d }) {
  const { soa } = d
  return (
    <div className="space-y-6">
      <PageTitle title="Statement of Account" sub="Assessment and payments recorded by the Cashier." />
      <div className={`${card} p-6 space-y-6`}>
        <div>
          <h3 className="font-bold text-sm mb-3">Assessment</h3>
          <Table head={['Particulars', 'Amount']}>
            {soa.assessments.map((a) => <tr key={a.description}><td className="py-3 font-medium">{a.description}</td><td className="font-semibold">{peso(a.amount)}</td></tr>)}
          </Table>
        </div>
        <div>
          <h3 className="font-bold text-sm mb-3">Payments</h3>
          <Table head={['OR Number', 'Date', 'Amount']} empty={soa.payments.length ? null : 'No payments yet.'}>
            {soa.payments.map((p) => <tr key={p.or_number}><td className="py-3 font-medium">{p.or_number}</td><td>{dateFmt(p.payment_date)}</td><td className="font-semibold">{peso(p.amount)}</td></tr>)}
          </Table>
        </div>
        <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex justify-between items-center">
          <span className="text-xs font-bold opacity-70">Balance Due</span>
          <span className={`text-lg font-extrabold ${soa.balance > 0 ? 'text-red-600' : 'text-emerald-600'}`}>{peso(soa.balance)}</span>
        </div>
      </div>
    </div>
  )
}

export function Requirements({ d }) {
  return (
    <div className="space-y-6">
      <PageTitle title="Enrollment Requirements & Clearance" sub="Registrar verification status of submitted documents and office clearances." />
      <div className={`${card} p-6 space-y-3`}>
        <h3 className="font-bold text-sm">Submitted documents</h3>
        {d.credentials.map((c) => (
          <div key={c.document_name} className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 flex justify-between items-center gap-4 text-xs">
            <div><p className="font-bold">{c.document_name}</p><p className="opacity-60 mt-0.5">{c.remarks}</p></div>
            <Badge tone={statusTone(c.status)}>{c.status}</Badge>
          </div>
        ))}
      </div>
      <div className={`${card} p-6 space-y-3`}>
        <h3 className="font-bold text-sm">Clearance</h3>
        {d.clearance.map((c) => (
          <div key={c.department_name} className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 flex justify-between items-center gap-4 text-xs">
            <div><p className="font-bold">{c.department_name}</p><p className="opacity-60 mt-0.5">{c.remarks}</p></div>
            <Badge tone={statusTone(c.status)}>{c.status}</Badge>
          </div>
        ))}
      </div>
    </div>
  )
}

const DOC_TYPES = ['Transcript of Records (TOR)', 'Certificate of Registration (COR)', 'Certificate of Enrollment', 'Good Moral Certificate']

export function Documents({ d, reload }) {
  const [type, setType] = useState(DOC_TYPES[0])
  const [copies, setCopies] = useState(1)
  const [purpose, setPurpose] = useState('')
  const [msg, setMsg] = useState(null)
  const [busy, setBusy] = useState(false)

  async function submit(e) {
    e.preventDefault()
    setBusy(true); setMsg(null)
    try {
      const r = await api('request_doc', { type, copies, purpose })
      setMsg({ ok: true, text: `Request submitted. Your reference number is ${r.ref_no}.` })
      setPurpose(''); setCopies(1)
      await reload()
    } catch (err) { setMsg({ ok: false, text: err.message }) }
    setBusy(false)
  }

  return (
    <div className="space-y-6">
      <PageTitle title="Request a Document" sub="Submit a request online. You will see its status here, so no need to queue at the Registrar." />
      <form onSubmit={submit} className={`${card} p-6 grid sm:grid-cols-2 gap-5`}>
        <div className="sm:col-span-2">
          <label htmlFor="doc-type" className="block text-xs font-semibold mb-1.5">Document type</label>
          <select id="doc-type" value={type} onChange={(e) => setType(e.target.value)} className={input}>
            {DOC_TYPES.map((t) => <option key={t}>{t}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="copies" className="block text-xs font-semibold mb-1.5">Number of copies (1 to 5)</label>
          <input id="copies" type="number" min="1" max="5" value={copies} onChange={(e) => setCopies(+e.target.value)} className={input} required />
        </div>
        <div>
          <label htmlFor="purpose" className="block text-xs font-semibold mb-1.5">Purpose</label>
          <input id="purpose" value={purpose} onChange={(e) => setPurpose(e.target.value)} maxLength={200} placeholder="e.g. Scholarship application" className={input} required />
        </div>
        <div className="sm:col-span-2 flex items-center gap-4">
          <button className={btn} disabled={busy}>{busy ? 'Submitting…' : 'Submit request'}</button>
          {msg && <p role="status" className={`text-xs font-medium ${msg.ok ? 'text-emerald-600' : 'text-red-600'}`}>{msg.text}</p>}
        </div>
      </form>
      <div className={`${card} p-6`}>
        <h3 className="font-bold text-sm mb-3">My requests</h3>
        <Table head={['Reference', 'Document', 'Copies', 'Purpose', 'Date', 'Status']} empty={d.documents.length ? null : 'No requests yet.'}>
          {d.documents.map((r) => (
            <tr key={r.ref_no}>
              <td className="py-3 font-semibold">{r.ref_no}</td><td>{r.document_type}</td><td>{r.copies}</td><td>{r.purpose}</td>
              <td>{dateFmt(r.request_date)}</td><td><Badge tone={statusTone(r.status)}>{r.status}</Badge></td>
            </tr>
          ))}
        </Table>
      </div>
    </div>
  )
}
