import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// In development, /api/* is forwarded to XAMPP (Apache + PHP) so the login session cookie
// stays same-origin. Folder name in htdocs must be: cuyotech-api
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api': {
        target: 'http://localhost',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, '/cuyotech-api'),
      },
    },
  },
})
