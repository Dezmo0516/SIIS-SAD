<?php
// CuyoTech SSIS - single API entry point. Usage: api.php?action=<name>
require_once __DIR__ . '/db.php';

session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();
header('Content-Type: application/json; charset=UTF-8');
header('X-Content-Type-Options: nosniff');

function out($data, $code = 200) { http_response_code($code); echo json_encode($data); exit; }
function q($sql, $params = []) { global $pdo; $s = $pdo->prepare($sql); $s->execute($params); return $s; }
function audit($adminId, $text) { q('INSERT INTO AuditTrail (admin_id, action_description) VALUES (?, ?)', [$adminId, $text]); }

$input = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $_GET['action'] ?? '';

// Basic CSRF defence: every state-changing request must carry this custom header (browsers block it cross-site).
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'ssis') {
    out(['error' => 'Invalid request.'], 400);
}

function requireStudent() {
    if (($_SESSION['kind'] ?? '') !== 'student') out(['error' => 'Please sign in as a student.'], 401);
    return (int) $_SESSION['id'];
}
function requireStaff(array $roles) {
    if (($_SESSION['kind'] ?? '') !== 'staff') out(['error' => 'Please sign in.'], 401);
    if (!in_array($_SESSION['role'], $roles, true)) out(['error' => 'You do not have access to this function.'], 403);
    return (int) $_SESSION['id'];
}

try {
    switch ($action) {

    case 'login':
        if (($_SESSION['fails'] ?? 0) >= 5 && time() - ($_SESSION['last_fail'] ?? 0) < 60) {
            out(['error' => 'Too many failed attempts. Please wait a minute.'], 429);
        }
        $email = strtolower(trim($input['email'] ?? ''));
        $pass = (string) ($input['password'] ?? '');
        if ($email === '' || $pass === '') out(['error' => 'Please fill in all fields.'], 422);

        $user = null;
        $row = q('SELECT student_id id, first_name, last_name, password_hash, is_active FROM Student WHERE email = ?', [$email])->fetch();
        if ($row) { $user = $row + ['kind' => 'student', 'role' => 'Student']; }
        else {
            $row = q('SELECT a.admin_id id, a.first_name, a.last_name, a.password_hash, a.is_active, r.role_name role FROM AdminUser a JOIN Role r ON r.role_id = a.role_id WHERE a.email = ?', [$email])->fetch();
            if ($row) $user = $row + ['kind' => 'staff'];
        }
        if (!$user || !password_verify($pass, $user['password_hash'])) {
            $_SESSION['fails'] = ($_SESSION['fails'] ?? 0) + 1;
            $_SESSION['last_fail'] = time();
            out(['error' => 'Incorrect email or password.'], 401);
        }
        if (!$user['is_active']) out(['error' => 'This account has been disabled. Please contact the administrator.'], 403);
        session_regenerate_id(true);
        $_SESSION = ['kind' => $user['kind'], 'id' => (int) $user['id'], 'role' => $user['role'],
                     'name' => $user['first_name'] . ' ' . $user['last_name']];
        if ($user['kind'] === 'staff') audit($user['id'], 'Logged in');
        out(['name' => $_SESSION['name'], 'role' => $_SESSION['role'], 'kind' => $_SESSION['kind']]);

    case 'me':
        if (empty($_SESSION['id'])) out(['error' => 'Not signed in.'], 401);
        out(['name' => $_SESSION['name'], 'role' => $_SESSION['role'], 'kind' => $_SESSION['kind']]);

    case 'logout':
        $_SESSION = [];
        session_destroy();
        out(['ok' => true]);

    // ---------- STUDENT PORTAL ----------
    case 'portal':
        $id = requireStudent();
        $profile = q('SELECT s.student_no, s.first_name, s.last_name, s.email, s.section, s.year_level, d.department_name
                      FROM Student s JOIN Department d ON d.department_id = s.department_id WHERE s.student_id = ?', [$id])->fetch();
        $courses = q('SELECT c.course_id, c.course_code, c.course_title, c.units, c.year_level, c.semester,
                             p.course_code prereq_code, e.grade, e.status, e.school_year
                      FROM Course c
                      LEFT JOIN Course p ON p.course_id = c.prerequisite_id
                      LEFT JOIN Enrollment e ON e.course_id = c.course_id AND e.student_id = ?
                      WHERE c.department_id = (SELECT department_id FROM Student WHERE student_id = ?)
                      ORDER BY c.year_level, c.semester, c.course_id', [$id, $id])->fetchAll();
        $assessments = q('SELECT school_year, semester, description, amount FROM Assessment WHERE student_id = ? ORDER BY assessment_id', [$id])->fetchAll();
        $payments = q('SELECT or_number, amount, payment_date FROM Payment WHERE student_id = ? ORDER BY payment_date', [$id])->fetchAll();
        $charged = array_sum(array_column($assessments, 'amount'));
        $paid = array_sum(array_column($payments, 'amount'));
        $units = 0; $gp = 0; $gu = 0;
        foreach ($courses as $c) {
            if ($c['status'] === 'Enrolled') $units += $c['units'];
            if ($c['status'] === 'Completed' && $c['grade'] !== null) { $gp += $c['grade'] * $c['units']; $gu += $c['units']; }
        }
        out([
            'profile' => $profile,
            'courses' => $courses,
            'soa' => ['assessments' => $assessments, 'payments' => $payments, 'charged' => $charged, 'paid' => $paid, 'balance' => $charged - $paid],
            'summary' => ['enrolled_units' => $units, 'gwa' => $gu ? round($gp / $gu, 2) : null],
            'credentials' => q('SELECT document_name, status, remarks FROM EnrollmentCredential WHERE student_id = ? ORDER BY credential_id', [$id])->fetchAll(),
            'clearance' => q('SELECT d.department_name, c.status, c.remarks FROM Clearance c JOIN Department d ON d.department_id = c.department_id WHERE c.student_id = ? ORDER BY c.clearance_id', [$id])->fetchAll(),
            'documents' => q('SELECT ref_no, document_type, copies, purpose, status, request_date FROM DocumentRequest WHERE student_id = ? ORDER BY request_id DESC', [$id])->fetchAll(),
        ]);

    case 'request_doc':
        $id = requireStudent();
        $types = ['Transcript of Records (TOR)', 'Certificate of Registration (COR)', 'Certificate of Enrollment', 'Good Moral Certificate'];
        $type = $input['type'] ?? '';
        $copies = (int) ($input['copies'] ?? 0);
        $purpose = trim($input['purpose'] ?? '');
        if (!in_array($type, $types, true) || $copies < 1 || $copies > 5 || strlen($purpose) < 3 || strlen($purpose) > 200) {
            out(['error' => 'Please check the request details (type, 1-5 copies, purpose).'], 422);
        }
        q('INSERT INTO DocumentRequest (student_id, document_type, copies, purpose) VALUES (?, ?, ?, ?)', [$id, $type, $copies, $purpose]);
        $rid = (int) $pdo->lastInsertId();
        $ref = sprintf('DR-%s-%04d', date('Y'), $rid);
        q('UPDATE DocumentRequest SET ref_no = ? WHERE request_id = ?', [$ref, $rid]);
        out(['ok' => true, 'ref_no' => $ref]);

    // ---------- STAFF ----------
    case 'staff_requests':
        requireStaff(['Registrar', 'System Admin']);
        out(['requests' => q('SELECT r.request_id, r.ref_no, r.document_type, r.copies, r.purpose, r.status, r.request_date,
                                     CONCAT(s.first_name, " ", s.last_name) student, s.student_no
                              FROM DocumentRequest r JOIN Student s ON s.student_id = r.student_id ORDER BY r.request_id DESC')->fetchAll()]);

    case 'update_request':
        $admin = requireStaff(['Registrar', 'System Admin']);
        $status = $input['status'] ?? '';
        $rid = (int) ($input['request_id'] ?? 0);
        if (!in_array($status, ['Pending', 'Processing', 'Ready for release', 'Released', 'Rejected'], true) || $rid < 1) out(['error' => 'Invalid request.'], 422);
        $n = q('UPDATE DocumentRequest SET status = ?, processed_by = ? WHERE request_id = ?', [$status, $admin, $rid])->rowCount();
        if ($n) audit($admin, "Set document request #$rid to $status");
        out(['ok' => true]);

    case 'staff_payments':
        requireStaff(['Cashier', 'System Admin']);
        out([
            'payments' => q('SELECT p.or_number, p.amount, p.payment_date, CONCAT(s.first_name, " ", s.last_name) student, s.student_no
                             FROM Payment p JOIN Student s ON s.student_id = p.student_id ORDER BY p.payment_id DESC')->fetchAll(),
            'students' => q('SELECT student_no, CONCAT(first_name, " ", last_name) name FROM Student ORDER BY last_name')->fetchAll(),
        ]);

    case 'record_payment':
        $admin = requireStaff(['Cashier', 'System Admin']);
        $sid = q('SELECT student_id FROM Student WHERE student_no = ?', [$input['student_no'] ?? ''])->fetchColumn();
        $amount = (float) ($input['amount'] ?? 0);
        $or = trim($input['or_number'] ?? '');
        if (!$sid || $amount <= 0 || $amount > 1000000 || !preg_match('/^[A-Za-z0-9-]{4,30}$/', $or)) out(['error' => 'Please check the student, amount, and OR number.'], 422);
        if (q('SELECT 1 FROM Payment WHERE or_number = ?', [$or])->fetch()) out(['error' => 'That OR number was already used.'], 409);
        q('INSERT INTO Payment (student_id, received_by, or_number, amount) VALUES (?, ?, ?, ?)', [$sid, $admin, $or, $amount]);
        audit($admin, "Recorded payment $or");
        out(['ok' => true]);

    // ---------- REGISTRAR: enrollment & grades ----------
    case 'registrar_students':
        requireStaff(['Registrar', 'System Admin']);
        out(['students' => q('SELECT student_no, CONCAT(first_name, " ", last_name) name, section FROM Student WHERE is_active = 1 ORDER BY last_name')->fetchAll()]);

    case 'registrar_courses':
        requireStaff(['Registrar', 'System Admin']);
        $sid = q('SELECT student_id FROM Student WHERE student_no = ?', [$_GET['student_no'] ?? ''])->fetchColumn();
        if (!$sid) out(['error' => 'Student not found.'], 404);
        $rows = q('SELECT c.course_id, c.course_code, c.course_title, c.units, c.year_level, c.semester, p.course_code prereq_code,
                          (p.course_id IS NULL OR (pe.status = "Completed" AND pe.grade <= 3.00)) prereq_met,
                          e.enrollment_id, e.grade, e.status, e.school_year
                   FROM Course c
                   LEFT JOIN Course p ON p.course_id = c.prerequisite_id
                   LEFT JOIN Enrollment pe ON pe.course_id = p.course_id AND pe.student_id = ?
                   LEFT JOIN Enrollment e ON e.course_id = c.course_id AND e.student_id = ?
                   ORDER BY c.year_level, c.semester, c.course_id', [$sid, $sid])->fetchAll();
        foreach ($rows as &$r) $r['prereq_met'] = (bool) $r['prereq_met'];
        out(['courses' => $rows]);

    case 'enroll_student':
        $admin = requireStaff(['Registrar', 'System Admin']);
        $sid = q('SELECT student_id FROM Student WHERE student_no = ? AND is_active = 1', [$input['student_no'] ?? ''])->fetchColumn();
        $cid = (int) ($input['course_id'] ?? 0);
        $course = q('SELECT course_id, course_code, prerequisite_id FROM Course WHERE course_id = ?', [$cid])->fetch();
        if (!$sid || !$course) out(['error' => 'Student or course not found.'], 404);
        if (q('SELECT 1 FROM Enrollment WHERE student_id = ? AND course_id = ?', [$sid, $cid])->fetch()) out(['error' => 'Student is already enrolled in or has taken this course.'], 409);
        if ($course['prerequisite_id']) {
            $ok = q('SELECT 1 FROM Enrollment WHERE student_id = ? AND course_id = ? AND status = "Completed" AND grade <= 3.00', [$sid, $course['prerequisite_id']])->fetch();
            if (!$ok) out(['error' => 'Prerequisite not yet passed. Enrollment is restricted until it is completed.'], 422);
        }
        q('INSERT INTO Enrollment (student_id, course_id, school_year, status) VALUES (?, ?, "2026-2027", "Enrolled")', [$sid, $cid]);
        audit($admin, 'Enrolled ' . $input['student_no'] . ' in ' . $course['course_code']);
        out(['ok' => true]);

    case 'encode_grade':
        $admin = requireStaff(['Registrar', 'System Admin']);
        $allowed = ['1.00', '1.25', '1.50', '1.75', '2.00', '2.25', '2.50', '2.75', '3.00', '5.00'];
        $grade = number_format((float) ($input['grade'] ?? 0), 2, '.', '');
        $eid = (int) ($input['enrollment_id'] ?? 0);
        if (!in_array($grade, $allowed, true) || $eid < 1) out(['error' => 'Invalid grade. Use 1.00 to 3.00 (passed) or 5.00 (failed).'], 422);
        $status = (float) $grade <= 3.0 ? 'Completed' : 'Failed';
        $n = q('UPDATE Enrollment SET grade = ?, status = ? WHERE enrollment_id = ?', [$grade, $status, $eid])->rowCount();
        if ($n) audit($admin, "Encoded grade $grade for enrollment #$eid");
        out(['ok' => true, 'status' => $status]);

    // ---------- DEPARTMENT: clearance ----------
    case 'staff_clearance':
        $admin = requireStaff(['Department', 'System Admin']);
        $dept = q('SELECT department_id FROM AdminUser WHERE admin_id = ?', [$admin])->fetchColumn();
        $sql = 'SELECT c.clearance_id, c.status, c.remarks, d.department_name, CONCAT(s.first_name, " ", s.last_name) student, s.student_no
                FROM Clearance c JOIN Student s ON s.student_id = c.student_id JOIN Department d ON d.department_id = c.department_id';
        $rows = ($_SESSION['role'] === 'Department' && $dept)
            ? q($sql . ' WHERE c.department_id = ? ORDER BY c.clearance_id', [$dept])->fetchAll()
            : q($sql . ' ORDER BY d.department_name, c.clearance_id')->fetchAll();
        out(['clearances' => $rows]);

    case 'update_clearance':
        $admin = requireStaff(['Department', 'System Admin']);
        $cid = (int) ($input['clearance_id'] ?? 0);
        $status = $input['status'] ?? '';
        $remarks = trim($input['remarks'] ?? '');
        if (!in_array($status, ['Cleared', 'Pending'], true) || $cid < 1 || strlen($remarks) > 255) out(['error' => 'Invalid request.'], 422);
        $row = q('SELECT department_id FROM Clearance WHERE clearance_id = ?', [$cid])->fetch();
        if (!$row) out(['error' => 'Clearance record not found.'], 404);
        if ($_SESSION['role'] === 'Department') {
            $dept = q('SELECT department_id FROM AdminUser WHERE admin_id = ?', [$admin])->fetchColumn();
            if ((int) $dept !== (int) $row['department_id']) out(['error' => 'You can only process clearances for your own office.'], 403);
        }
        q('UPDATE Clearance SET status = ?, remarks = ? WHERE clearance_id = ?', [$status, $remarks, $cid]);
        audit($admin, "Set clearance #$cid to $status");
        out(['ok' => true]);

    // ---------- CASHIER: receipt ----------
    case 'receipt':
        requireStaff(['Cashier', 'System Admin']);
        $p = q('SELECT p.or_number, p.amount, p.payment_date, s.student_id, s.student_no, CONCAT(s.first_name, " ", s.last_name) student,
                       COALESCE(CONCAT(a.first_name, " ", a.last_name), "") cashier
                FROM Payment p JOIN Student s ON s.student_id = p.student_id LEFT JOIN AdminUser a ON a.admin_id = p.received_by
                WHERE p.or_number = ?', [$_GET['or'] ?? ''])->fetch();
        if (!$p) out(['error' => 'Receipt not found.'], 404);
        $charged = (float) q('SELECT COALESCE(SUM(amount),0) FROM Assessment WHERE student_id = ?', [$p['student_id']])->fetchColumn();
        $paid = (float) q('SELECT COALESCE(SUM(amount),0) FROM Payment WHERE student_id = ?', [$p['student_id']])->fetchColumn();
        unset($p['student_id']);
        out($p + ['balance' => $charged - $paid]);

    // ---------- ADMIN: user management ----------
    case 'admin_users':
        requireStaff(['System Admin']);
        out([
            'staff' => q('SELECT a.admin_id id, a.email, CONCAT(a.first_name, " ", a.last_name) name, r.role_name role, a.is_active FROM AdminUser a JOIN Role r ON r.role_id = a.role_id ORDER BY a.admin_id')->fetchAll(),
            'students' => q('SELECT student_id id, student_no, email, CONCAT(first_name, " ", last_name) name, section, is_active FROM Student ORDER BY student_id')->fetchAll(),
            'audit' => q('SELECT COALESCE(CONCAT(a.first_name, " ", a.last_name), "(removed)") who, t.action_description, t.log_timestamp
                          FROM AuditTrail t LEFT JOIN AdminUser a ON a.admin_id = t.admin_id ORDER BY t.log_id DESC LIMIT 20')->fetchAll(),
        ]);

    case 'create_user':
        $admin = requireStaff(['System Admin']);
        $kind = $input['kind'] ?? '';
        $email = strtolower(trim($input['email'] ?? ''));
        $first = trim($input['first_name'] ?? ''); $last = trim($input['last_name'] ?? '');
        $pass = (string) ($input['password'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $first === '' || $last === '' || strlen($first) > 50 || strlen($last) > 50) out(['error' => 'Please check the name and email.'], 422);
        if (strlen($pass) < 8) out(['error' => 'Password must be at least 8 characters.'], 422);
        if (q('SELECT 1 FROM Student WHERE email = ? UNION SELECT 1 FROM AdminUser WHERE email = ?', [$email, $email])->fetch()) out(['error' => 'That email is already in use.'], 409);
        $hash = password_hash($pass, PASSWORD_DEFAULT);
        if ($kind === 'staff') {
            $role = q('SELECT role_id FROM Role WHERE role_name = ?', [$input['role'] ?? ''])->fetchColumn();
            if (!$role) out(['error' => 'Please choose a valid role.'], 422);
            $dept = ($input['role'] === 'Department') ? 1 : null;
            q('INSERT INTO AdminUser (email, password_hash, first_name, last_name, role_id, department_id) VALUES (?, ?, ?, ?, ?, ?)', [$email, $hash, $first, $last, $role, $dept]);
        } elseif ($kind === 'student') {
            $no = trim($input['student_no'] ?? '');
            $sec = trim($input['section'] ?? '');
            $yr = (int) ($input['year_level'] ?? 0);
            if (!preg_match('/^[A-Za-z0-9-]{4,20}$/', $no) || strlen($sec) > 10 || $yr < 1 || $yr > 4) out(['error' => 'Please check the student number, section, and year level.'], 422);
            if (q('SELECT 1 FROM Student WHERE student_no = ?', [$no])->fetch()) out(['error' => 'That student number is already in use.'], 409);
            q('INSERT INTO Student (student_no, email, password_hash, first_name, last_name, department_id, section, year_level) VALUES (?, ?, ?, ?, ?, 1, ?, ?)', [$no, $email, $hash, $first, $last, $sec, $yr]);
        } else out(['error' => 'Invalid user type.'], 422);
        audit($admin, "Created $kind account $email");
        out(['ok' => true]);

    case 'set_active':
        $admin = requireStaff(['System Admin']);
        $kind = $input['kind'] ?? ''; $uid = (int) ($input['id'] ?? 0); $active = !empty($input['active']) ? 1 : 0;
        if (!in_array($kind, ['staff', 'student'], true) || $uid < 1) out(['error' => 'Invalid request.'], 422);
        if ($kind === 'staff' && $uid === $admin) out(['error' => 'You cannot disable your own account.'], 422);
        $table = $kind === 'staff' ? 'AdminUser' : 'Student'; $col = $kind === 'staff' ? 'admin_id' : 'student_id';
        q("UPDATE $table SET is_active = ? WHERE $col = ?", [$active, $uid]);
        audit($admin, ($active ? 'Enabled' : 'Disabled') . " $kind account #$uid");
        out(['ok' => true]);

    case 'reset_password':
        $admin = requireStaff(['System Admin']);
        $kind = $input['kind'] ?? ''; $uid = (int) ($input['id'] ?? 0); $pass = (string) ($input['password'] ?? '');
        if (!in_array($kind, ['staff', 'student'], true) || $uid < 1) out(['error' => 'Invalid request.'], 422);
        if (strlen($pass) < 8) out(['error' => 'Password must be at least 8 characters.'], 422);
        $table = $kind === 'staff' ? 'AdminUser' : 'Student'; $col = $kind === 'staff' ? 'admin_id' : 'student_id';
        q("UPDATE $table SET password_hash = ? WHERE $col = ?", [password_hash($pass, PASSWORD_DEFAULT), $uid]);
        audit($admin, "Reset password of $kind account #$uid");
        out(['ok' => true]);

    default:
        out(['error' => 'Unknown action.'], 404);
    }
} catch (Throwable $e) {
    error_log('SSIS API error: ' . $e->getMessage());
    out(['error' => 'Something went wrong on the server.'], 500);
}
